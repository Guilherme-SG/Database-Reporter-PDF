<?php
// Only extentions exceptions
class MySQLException extends Exception {}
class MySQLDuplicateKeyException extends MySQLException {}
?>